import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/*
<html>
<body>
<applet code="PR11.class" width=750 height=250></applet>
</body>
</html>
*/
public class PR11 extends JApplet{
    @Override
    public void init() {
        super.init();

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Container c = getContentPane();
        JTextField t = new JTextField();
        JButton b = new JButton("Submit");
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(t.getText());
            }
        });
        c.add(t);
        c.add(b);
        c.setSize(750,250);
        c.setLayout(new FlowLayout());
        c.setVisible(true);
    }
}