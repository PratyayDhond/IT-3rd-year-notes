import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.*;

public class Client {
    public static void main(String[] args) throws Exception{
        intf i =(intf) Naming.lookup("rmi://127.0.0.1/AddServer");
        double a,b;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str = br.readLine();
        a = Double.parseDouble(str);
        str = br.readLine();
        b = Double.parseDouble(str);

        System.out.println(i.add(a,b));
    }
}