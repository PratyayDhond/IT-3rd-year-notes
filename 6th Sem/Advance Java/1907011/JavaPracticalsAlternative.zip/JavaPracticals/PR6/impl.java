import java.rmi. *;
import java.rmi.server.*;

public class impl extends UnicastRemoteObject implements intf{

    impl() throws Exception{
        super();
    }

    public double add(double d1, double d2) throws Exception{
        return d1+d2;
    }
}