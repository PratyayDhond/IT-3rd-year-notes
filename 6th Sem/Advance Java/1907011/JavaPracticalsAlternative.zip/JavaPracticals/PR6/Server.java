import java.rmi.*;

public class Server{
    public static void main(String[] args) throws Exception{
        impl i = new impl();
        Naming.rebind("AddServer",i);
    }
}