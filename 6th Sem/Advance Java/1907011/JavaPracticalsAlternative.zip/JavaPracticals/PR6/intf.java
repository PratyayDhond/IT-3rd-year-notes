import java.rmi.*;

interface intf extends Remote{
    double add(double d1, double d2) throws Exception;
}