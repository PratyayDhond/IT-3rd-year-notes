import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PR10{
    boolean checkBox = false;
    JFrame frame = null;
    JPanel panel = null;
    String[][] data = {
            {"Pratyay Dhond", "1907011", "Lightning"},
            {"Aveena Dange", "2007004", "Unicorn"},
            {"Priyanshu Lapkale", "1907025", "Nightmare"},
            };
    String columns[] = {"Name", "Roll Number", "Nickname"};
    JTable table = new JTable(data,columns);

    PR10(){
        frame = new JFrame("Practical No. 10");
        frame.setSize(750,250);
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JCheckBox check = new JCheckBox("Check");
        check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkBox = !checkBox;
                System.out.println("Check : " + checkBox);
                setTable(checkBox);
            }
        });
        panel = new JPanel();
        panel.add(table);
        frame.add(check);
        frame.add(panel);
        frame.setVisible(true);
    }
    public void setTable(boolean checkBox){
        if(!checkBox){
            panel.remove(table);
        }else{
//            table = ;
            panel.add(table);
        }
        panel.validate();
        panel.repaint();
    }

    public static void main(String[] args) {
        Object obj = new PR10();
    }
}
