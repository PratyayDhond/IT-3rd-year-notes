import java.io.DataInputStream;
import java.net.*;

public class S1{
    public static void main(String[] args) throws Exception{
        ServerSocket ss = new ServerSocket(1234);
        Socket s = ss.accept();
        DataInputStream in = new DataInputStream(s.getInputStream());
        String str = in.readUTF();
        System.out.println(str);
    }
}