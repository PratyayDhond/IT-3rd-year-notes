import java.io.DataOutputStream;
import java.net.*;
import java.util.Scanner;

public class C1{
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost",1234);
        DataOutputStream out = new DataOutputStream(s.getOutputStream());
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        out.writeUTF(str);
    }
}