import java.io.Serializable;

public class Bean implements Serializable{
    private int age;
    private String name;

    Bean(){
        age = 0;
        name = "";
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        Bean b = new Bean();
        b.setAge(19);
        b.setName("Pratyay");
        System.out.println(b.getAge());
        System.out.println(b.getName());
    }
}