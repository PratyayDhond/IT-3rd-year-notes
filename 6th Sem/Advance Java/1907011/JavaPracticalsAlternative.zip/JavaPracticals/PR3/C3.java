import java.net.*;
import java.io.*;
import java.util.Scanner;

public class C3{
    public static void main(String[] args) throws Exception{
        Socket s = new Socket("localhost",1234);
        boolean flag = true;
        Scanner sc = new Scanner(System.in);
        String str;
        DataInputStream in = new DataInputStream( s.getInputStream());
        DataOutputStream out = new DataOutputStream( s.getOutputStream());
        while(flag){
            System.out.print("Client> ");
            str = sc.nextLine();
            out.writeUTF(str);
            if(str.equals("-1")){
                flag = false;
                System.out.println("Client> CONNECTION CLOSED SUCCESSFULLY. EXIT CODE: " + Math.random()%440);
                continue;
            }
            System.out.print("Server> ");
            str = in.readUTF();
            if(str.equals("-1")){
                flag = false;
                System.out.println("The Client has closed the connection");
            }
            else
                System.out.println(str);
        }
    }
}