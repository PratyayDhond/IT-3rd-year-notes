import java.util.*;
import java.io.*;
import java.net.*;

public class S3{
    public static void main(String[] args) throws Exception{
        ServerSocket ss = new ServerSocket(1234);
        Socket s = ss.accept();
        Scanner sc = new Scanner(System.in);
        DataOutputStream out = new DataOutputStream(s.getOutputStream());
        DataInputStream in = new DataInputStream(s.getInputStream());
        boolean flag = true;
        String str;

        while(flag){
            System.out.print("Client> ");
            str = in.readUTF();
            if(str.equals("-1")){
                flag = false;
                System.out.println("Client Has Closed The Connection.");
                continue;
            }else{
                System.out.println(str);
            }
            System.out.print("Server> ");
            str = sc.nextLine();
            out.writeUTF(str);
            if(str.equals("-1")){
                flag = false;
                System.out.println("Server> CONNECTION CLOSED SUCCESSFULLY.cd " );
                continue;
            }
        }
    }
}