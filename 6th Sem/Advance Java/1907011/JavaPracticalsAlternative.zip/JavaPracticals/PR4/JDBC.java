import java.util.Scanner;
import java.sql.*;

public class JDBC{
    public static void main(String[] args) throws Exception{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/PR4","","");
        Statement stmt = con.createStatement();

        Scanner sc = new Scanner(System.in);
        String name;
        int roll;

        int max = 0;
        int marks = 0;

        System.out.print("Name: ");
        name = sc.nextLine();
        System.out.print("Roll: ");
        roll = sc.nextInt();
        for (int i = 1; i <= 5; i++){
            System.out.print("Marks in subject ");
            System.out.print(i + ": ");
            int temp = sc.nextInt();
            if(temp > max)
                max = temp;
            marks += temp;
        }
        System.out.println("INSERT INTO student VALUES("+ roll + ", " + name + ", " + marks + ", " + (marks/5.0) + ", "+ max +")");
        try {
//            stmt.executeUpdate("INSERT INTO student VALUES("+ roll + ", " + name + ", " + marks + ", " + (marks/5.0) + ", "+ max +")" );
        }catch (Exception e){
            System.out.println(e);
        }
    }
}