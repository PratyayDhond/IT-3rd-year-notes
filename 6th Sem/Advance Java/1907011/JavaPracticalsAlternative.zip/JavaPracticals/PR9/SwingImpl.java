import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SwingImpl {
    private int count = 0;
    SwingImpl(){
        JFrame frame = new JFrame("Practical No 9");
        frame.setSize(750,250);
        frame.setLayout(new FlowLayout());
        JButton btn = new JButton("Click me");
        JLabel label = new JLabel("Clicks : " + count);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                     count++;
                     label.setText("Clicks : " + count);
            }
        });
        frame.add(btn);
        frame.add(label);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingImpl s = new SwingImpl();
    }
}