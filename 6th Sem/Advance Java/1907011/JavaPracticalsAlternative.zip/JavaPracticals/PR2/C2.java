import java.net.*;
import java.util.Scanner;

public class C2{
    public static void main(String[] args) throws Exception{
        DatagramSocket ds = new DatagramSocket();
        InetAddress inet = InetAddress.getLocalHost();
        Scanner sc = new Scanner(System.in);
        String str;
        do{
            str = sc.nextLine();
            byte[] b = str.getBytes();
            DatagramPacket dp = new DatagramPacket(b,b.length,inet,1234);
            ds.send(dp);
        }while(!str.equals("-1"));
        ds.close();
        sc.close();
    }
}